function getHistory(){
    return document.getElementById("history-value").innerText;
}

function printHistory(num){
    document.getElementById("history-vlue").innertext=num;
}

function get0output(){
    document.getElementById("output-value").innerText;
}

function print0output(){
    if(num == ""){
        document.getElementById("output-value").innerText=num;
    }
    else{
        document.getElementById("output-value").innerText=getFormattedNumber
    }
}

function reversedNumberFormat(num){
    return Number(replace(/,/g,""));
}

var operator = document.getElementsByClassName("operator");
for(var i= o; i<operator.length; i++){
    operator(i).addEventListener('click' ,function(){
        if(this.id == "clear"){
            printHistory("");
            print0output("");
        }
        else if (this.id=="backspace") {
            var output=reversedNumberFormat(get0output()).toString();
            if (output){
                output= output.substr(0,history,length-1);
                print0output(output);
            }
        }
        else {
            var output = get0output();
            var history = getHistory();
            if(output=="" && history!=""){
                if(isNaN(history[history.length-1])){
                    history=history.substr(0,history.length-1);
                }
            }
            if(output = "" || history!==""){
                output = output== ""
            }
        }
    })
}

var number = document.getElementsByClassName("number");
for(var i = 0; i<number.length; i++){

}